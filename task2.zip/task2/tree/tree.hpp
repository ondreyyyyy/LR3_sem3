#ifndef TREE_HPP
#define TREE_HPP

#include <string>
#include <cstdint>

using namespace std;

enum Color : std::uint8_t {
    RED,
    BLACK
};

class TNode {
public:
    int key;
    Color color;
    TNode* left;
    TNode* right;
    TNode* parent;
    TNode(const int& key, const Color& color, TNode* parent);
};

class Tree {
private:
    void removeSubTree(TNode* node);
    void printTreeHelper(TNode* node, const string& prefix, bool isLeft, bool isRoot) const;
    void insertFixup(TNode* newNode);
    void deleteFixup(TNode* fixupNode);
    void handleLeftCase(TNode*& fixupNode);
    void handleLeftSubcases(TNode*& fixupNode, TNode* siblingNode);
    void handleRightCase(TNode*& fixupNode);
    void handleRightSubcases(TNode*& fixupNode, TNode* siblingNode);
public:
    TNode* root;
    TNode* nil;
    Tree();
    ~Tree();

    void insert(const int& value);
    void findNodeV(const int& value) const;
    auto findMaximum(TNode* node) const -> TNode*;
    auto findMinimum(TNode* node) const -> TNode*;
    void deleteNode(TNode* nodeToDelete);
    void replaceNode(TNode* oldNode, TNode* newNode);
    void rightRotate(TNode* pivotNode);
    void leftRotate(TNode* pivotNode);
    [[nodiscard]] auto findNode(const int& value) const -> TNode*;
    void printTree() const;
};

#endif