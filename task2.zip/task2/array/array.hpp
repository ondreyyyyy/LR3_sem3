#ifndef ARRAY_HPP
#define ARRAY_HPP

#include <string>
using namespace std;

class DynArray {
private:
    string* data;
    int size;
public:
    int capacity;
    DynArray();
    DynArray(int capacity);
    ~DynArray();

    void addAtIndex(const int& index, const string& newData);
    void pushBackArr(const string& newData);
    [[nodiscard]] auto getElementIndex(const int& index) const -> string;
    void removeFromIndex(const int& index);
    void replacementElement(const int& index, const string& newValue);
    [[nodiscard]] auto getSize() const -> int;
    void printArray() const;
    auto getCap() const -> int;
};

#endif