#include "array.hpp"
#include <iostream>
#include <cassert>

using namespace std;

// Добавляем функцию для освобождения памяти строк
extern "C" void freeString(char* str) {
    if (str != nullptr) {
        delete[] str;
    }
}

void testDynArray() {
    cout << "=== ТЕСТИРОВАНИЕ DynArray ===" << endl;

    // Тест 1: Создание массива и базовые операции
    cout << "\n1. Тест создания массива и базовых операций:\n";
    DynArray* arr = createArray();
    
    arrayPushBack(arr, "Hello");
    arrayPushBack(arr, "World");
    arrayPushBack(arr, "Test");
    
    arrayPrint(arr);
    cout << "Размер массива: " << arrayGetSize(arr) << endl;

    // Тест 2: Получение элементов через C-функцию
    cout << "\n2. Тест получения элементов через C-функцию:" << endl;
    char* element1 = arrayGetElementIndex(arr, 0);
    char* element2 = arrayGetElementIndex(arr, 1);
    char* element3 = arrayGetElementIndex(arr, 2);
    
    cout << "Элемент 0: " << (element1 ? element1 : "NULL") << endl;
    cout << "Элемент 1: " << (element2 ? element2 : "NULL") << endl;
    cout << "Элемент 2: " << (element3 ? element3 : "NULL") << endl;
    
    // Освобождаем память
    freeString(element1);
    freeString(element2);
    freeString(element3);

    // Тест 3: Добавление по индексу
    cout << "\n3. Тест добавления по индексу:" << endl;
    arrayAddAtIndex(arr, 1, "Middle");
    arrayPrint(arr);

    // Тест 4: Замена элемента
    cout << "\n4. Тест замены элемента:" << endl;
    arrayReplacement(arr, 2, "Replaced");
    arrayPrint(arr);

    // Тест 5: Удаление элемента
    cout << "\n5. Тест удаления элемента:" << endl;
    arrayRemoveIndex(arr, 1);
    arrayPrint(arr);

    // Тест 6: Получение элементов через метод класса
    cout << "\n6. Тест получения элементов через метод класса:" << endl;
    string elem0 = arr->getElementIndex(0);
    string elem1 = arr->getElementIndex(1);
    cout << "Через метод класса - элемент 0: " << elem0 << endl;
    cout << "Через метод класса - элемент 1: " << elem1 << endl;

    // Тест 7: Граничные случаи
    cout << "\n7. Тест граничных случаев:" << endl;
    
    // Попытка получить элемент с неверным индексом через C-функцию
    char* invalidElement = arrayGetElementIndex(arr, 10);
    cout << "Неверный индекс (C): " << (invalidElement ? invalidElement : "NULL") << endl;
    freeString(invalidElement);

    // Попытка получить элемент с неверным индексом через метод класса
    string invalidElement2 = arr->getElementIndex(10);
    cout << "Неверный индекс (класс): '" << invalidElement2 << "'" << endl;

    // Попытка удалить неверный индекс
    arrayRemoveIndex(arr, -1);
    arrayRemoveIndex(arr, 100);
    arrayPrint(arr);

    // Тест 8: Работа с пустым массивом
    cout << "\n8. Тест пустого массива:" << endl;
    DynArray* emptyArr = createArray();
    arrayPrint(emptyArr);
    cout << "Размер пустого массива: " << arrayGetSize(emptyArr) << endl;
    
    char* emptyElement = arrayGetElementIndex(emptyArr, 0);
    cout << "Элемент из пустого массива: " << (emptyElement ? emptyElement : "NULL") << endl;
    freeString(emptyElement);

    // Тест 9: Множественное добавление (проверка увеличения capacity)
    cout << "\n9. Тест множественного добавления:" << endl;
    for (int i = 0; i < 10; i++) {
        arrayPushBack(emptyArr, "Element_" + to_string(i));
    }
    arrayPrint(emptyArr);

    // Тест 10: Создание массива с начальной capacity
    cout << "\n10. Тест массива с начальной capacity:" << endl;
    DynArray preSizedArr(5);
    preSizedArr.pushBackArr("One");
    preSizedArr.pushBackArr("Two");
    preSizedArr.pushBackArr("Three");
    preSizedArr.printArray();

    // Тест 11: Все методы класса напрямую
    cout << "\n11. Тест всех методов класса напрямую:" << endl;
    DynArray directArr;
    directArr.pushBackArr("First");
    directArr.pushBackArr("Third");
    directArr.addAtIndex(1, "Second");
    directArr.printArray();
    
    cout << "Размер: " << directArr.getSize() << endl;
    
    string directElement = directArr.getElementIndex(1);
    cout << "Элемент с индексом 1: " << directElement << endl;
    
    directArr.replacementElement(0, "FirstReplaced");
    directArr.removeFromIndex(2);
    directArr.printArray();

    // Очистка
    cout << "\n12. Очистка:" << endl;
    destroyArray(arr);
    destroyArray(emptyArr);
    
    cout << "Все тесты завершены успешно!" << endl;
}

void testMixedUsage() {
    cout << "\n=== ТЕСТИРОВАНИЕ СМЕШАННОГО ИСПОЛЬЗОВАНИЯ ===" << endl;
    
    DynArray* arr = createArray();
    
    // Используем C-функции
    arrayPushBack(arr, "C_Function_1");
    arrayPushBack(arr, "C_Function_2");
    
    // Используем методы класса
    arr->pushBackArr("Class_Method_1");
    arr->addAtIndex(1, "Class_Insert");
    
    // Смешанное использование
    arrayPrint(arr); // C-функция
    cout << "Size via C: " << arrayGetSize(arr) << endl;
    cout << "Size via class: " << arr->getSize() << endl;
    
    // Получаем элементы обоими способами
    char* cElement = arrayGetElementIndex(arr, 0);
    string classElement = arr->getElementIndex(0);
    
    cout << "C function element: " << (cElement ? cElement : "NULL") << endl;
    cout << "Class method element: " << classElement << endl;
    
    freeString(cElement);
    destroyArray(arr);
}

int main() {
    try {
        testDynArray();
        testMixedUsage();
        
        cout << "\n=== ВСЕ ТЕСТЫ ПРОЙДЕНЫ ===" << endl;
        return 0;
    } catch (const exception& e) {
        cerr << "Ошибка: " << e.what() << endl;
        return 1;
    }
}