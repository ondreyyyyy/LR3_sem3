package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

var arrays = make(map[string]*DynArray)
var forwardLists = make(map[string]*ForwardList)
var doubleLists = make(map[string]*DoubleFL)
var stacks = make(map[string]*Stack)
var queues = make(map[string]*Queue)

func saveToFile(filename string) {
	file, err := os.Create(filename)
	if err != nil {
		return
	}
	defer file.Close()

	writer := bufio.NewWriter(file)

	for name, arr := range arrays {
		writer.WriteString("ARRAY " + name)
		for i := 0; i < arr.size; i++ {
			elem, _ := getElementIndex(i, *arr)
			writer.WriteString(" " + elem)
		}
		writer.WriteString("\n")
	}

	for name, list := range forwardLists {
		writer.WriteString("FORWARDLIST " + name)
		current := list.head
		for current != nil {
			writer.WriteString(" " + current.value)
			current = current.next
		}
		writer.WriteString("\n")
	}

	for name, list := range doubleLists {
		writer.WriteString("DOUBLELIST " + name)
		current := list.head
		for current != nil {
			writer.WriteString(" " + current.value)
			current = current.next
		}
		writer.WriteString("\n")
	}

	for name, stack := range stacks {
		writer.WriteString("STACK " + name)
		// Собираем элементы стека в правильном порядке (от вершины к дну)
		elements := []string{}
		current := stack.head
		for current != nil {
			elements = append(elements, current.value)
			current = current.next
		}
		// Записываем элементы (первый элемент - вершина стека)
		for _, elem := range elements {
			writer.WriteString(" " + elem)
		}
		writer.WriteString("\n")
	}

	for name, queue := range queues {
		writer.WriteString("QUEUE " + name)
		current := queue.head
		for current != nil {
			writer.WriteString(" " + current.value)
			current = current.next
		}
		writer.WriteString("\n")
	}

	writer.Flush()
}

func loadFromFile(filename string) {
	file, err := os.Open(filename)
	if err != nil {
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}

		tokens := strings.Fields(line)
		if len(tokens) < 2 {
			continue
		}

		typeStr := tokens[0]
		name := tokens[1]

		switch typeStr {
		case "ARRAY":
			capacity := len(tokens) - 2
			if capacity <= 0 {
				capacity = 1
			}
			arr := createArr(capacity)
			for i := 2; i < len(tokens); i++ {
				pushBackArr(tokens[i], &arr)
			}
			arrays[name] = &arr

		case "FORWARDLIST":
			if len(tokens) > 2 {
				list := createFL(tokens[2])
				for i := 3; i < len(tokens); i++ {
					flAddAtTail(&list, tokens[i])
				}
				forwardLists[name] = &list
			}

		case "DOUBLELIST":
			if len(tokens) > 2 {
				list := createDoubleFL(tokens[2])
				for i := 3; i < len(tokens); i++ {
					dblAddAtTail(&list, tokens[i])
				}
				doubleLists[name] = &list
			}

		case "STACK":
			stack := createStack()
			// Загружаем элементы в стек (первый элемент в файле становится вершиной)
			for i := 2; i < len(tokens); i++ {
				push(stack, tokens[i])
			}
			stacks[name] = stack

		case "QUEUE":
			queue := createQueue()
			for i := 2; i < len(tokens); i++ {
				enqueue(queue, tokens[i])
			}
			queues[name] = queue
		}
	}
}

func processPrintCommand(args []string) {
	if len(args) != 2 {
		fmt.Println("Ошибка: неверное количество аргументов для PRINT. Ожидается: PRINT <name>")
		return
	}

	name := args[1]

	if arr, exists := arrays[name]; exists {
		fmt.Printf("Содержимое массива '%s': ", name)
		printArray(*arr)
	} else if list, exists := forwardLists[name]; exists {
		fmt.Printf("Содержимое односвязного списка '%s': ", name)
		printFL(list.head)
	} else if list, exists := doubleLists[name]; exists {
		fmt.Printf("Содержимое двусвязного списка '%s': ", name)
		printDoubleFL(list.head)
	} else if stack, exists := stacks[name]; exists {
		fmt.Printf("Содержимое стека '%s': ", name)
		printStack(stack)
	} else if queue, exists := queues[name]; exists {
		fmt.Printf("Содержимое очереди '%s': ", name)
		printQueue(queue)
	} else {
		fmt.Printf("Ошибка: структура данных с именем '%s' не найдена\n", name)
	}
}

// Добавляем функцию printStack для вывода стека
func printStack(stack *Stack) {
	if stack.head == nil {
		fmt.Println("стек пуст")
		return
	}

	fmt.Print("стек: ")
	current := stack.head
	for current != nil {
		fmt.Print(current.value)
		if current.next != nil {
			fmt.Print(" -> ")
		}
		current = current.next
	}
	fmt.Println()
}

// Добавляем функцию printQueue для вывода очереди
func printQueue(queue *Queue) {
	if queue.head == nil {
		fmt.Println("очередь пуста")
		return
	}

	fmt.Print("очередь: ")
	current := queue.head
	for current != nil {
		fmt.Print(current.value)
		if current.next != nil {
			fmt.Print(" -> ")
		}
		current = current.next
	}
	fmt.Println()
}

// Остальные функции остаются без изменений...
func processArrayCommand(args []string) {
	if len(args) < 2 {
		fmt.Println("Ошибка: недостаточно аргументов для команды", args[0])
		return
	}

	name := args[1]

	switch args[0] {
	case "MCREATE":
		if len(args) > 3 {
			fmt.Println("Ошибка: слишком много аргументов для MCREATE")
			return
		}
		if _, exists := arrays[name]; exists {
			fmt.Printf("Ошибка: массив '%s' уже существует\n", name)
			return
		}
		capacity := 10
		if len(args) > 2 {
			cap, err := strconv.Atoi(args[2])
			if err != nil {
				fmt.Println("Ошибка: неверная емкость массива")
				return
			}
			capacity = cap
		}
		arr := createArr(capacity)
		arrays[name] = &arr
		fmt.Printf("Создание массива '%s' успешно\n", name)

	case "MPUSH":
		if len(args) != 3 {
			fmt.Println("Ошибка: неверное количество аргументов для MPUSH")
			return
		}
		arr, exists := arrays[name]
		if !exists {
			fmt.Printf("Ошибка: массив '%s' не существует\n", name)
			return
		}
		pushBackArr(args[2], arr)
		fmt.Printf("Добавление элемента в массив '%s' успешно\n", name)

	case "MINSERT":
		if len(args) != 4 {
			fmt.Println("Ошибка: неверное количество аргументов для MINSERT")
			return
		}
		arr, exists := arrays[name]
		if !exists {
			fmt.Printf("Ошибка: массив '%s' не существует\n", name)
			return
		}
		index, err := strconv.Atoi(args[2])
		if err != nil || index < 0 || index > arr.size {
			fmt.Println("Ошибка: индекс вне диапазона")
			return
		}
		addAtIndex(index, args[3], arr)
		fmt.Printf("Вставка элемента в массив '%s' успешна\n", name)

	case "MDEL":
		if len(args) != 3 {
			fmt.Println("Ошибка: неверное количество аргументов для MDEL")
			return
		}
		arr, exists := arrays[name]
		if !exists {
			fmt.Printf("Ошибка: массив '%s' не существует\n", name)
			return
		}
		index, err := strconv.Atoi(args[2])
		if err != nil || index < 0 || index >= arr.size {
			fmt.Println("Ошибка: индекс вне диапазона")
			return
		}
		value, _ := getElementIndex(index, *arr)
		removeFromIndex(index, arr)
		fmt.Printf("Удаление элемента '%s' из массива '%s' успешно\n", value, name)

	case "MGET":
		if len(args) != 3 {
			fmt.Println("Ошибка: неверное количество аргументов для MGET")
			return
		}
		arr, exists := arrays[name]
		if !exists {
			fmt.Printf("Ошибка: массив '%s' не существует\n", name)
			return
		}
		index, err := strconv.Atoi(args[2])
		if err != nil || index < 0 || index >= arr.size {
			fmt.Println("Ошибка: индекс вне диапазона")
			return
		}
		value, _ := getElementIndex(index, *arr)
		fmt.Printf("Элемент массива '%s' по индексу %d: %s\n", name, index, value)

	case "MSET":
		if len(args) != 4 {
			fmt.Println("Ошибка: неверное количество аргументов для MSET")
			return
		}
		arr, exists := arrays[name]
		if !exists {
			fmt.Printf("Ошибка: массив '%s' не существует\n", name)
			return
		}
		index, err := strconv.Atoi(args[2])
		if err != nil || index < 0 || index >= arr.size {
			fmt.Println("Ошибка: индекс вне диапазона")
			return
		}
		replacementElement(index, args[3], arr)
		fmt.Printf("Замена элемента в массиве '%s' успешна\n", name)

	case "MSIZE", "MLENGTH":
		if len(args) != 2 {
			fmt.Println("Ошибка: неверное количество аргументов для", args[0])
			return
		}
		arr, exists := arrays[name]
		if !exists {
			fmt.Printf("Ошибка: массив '%s' не существует\n", name)
			return
		}
		size := genLength(*arr)
		fmt.Printf("Размер массива '%s': %d\n", name, size)
	}
}

func processStackCommand(args []string) {
	if len(args) < 2 {
		fmt.Println("Ошибка: недостаточно аргументов для команды", args[0])
		return
	}

	name := args[1]

	switch args[0] {
	case "SCREATE":
		if len(args) != 2 {
			fmt.Println("Ошибка: неверное количество аргументов для SCREATE")
			return
		}
		if _, exists := stacks[name]; exists {
			fmt.Printf("Ошибка: стек '%s' уже существует\n", name)
			return
		}
		stacks[name] = createStack()
		fmt.Printf("Создание стека '%s' успешно\n", name)

	case "SPUSH":
		if len(args) != 3 {
			fmt.Println("Ошибка: неверное количество аргументов для SPUSH")
			return
		}
		stack, exists := stacks[name]
		if !exists {
			fmt.Printf("Ошибка: стек '%s' не существует\n", name)
			return
		}
		push(stack, args[2])
		fmt.Printf("Добавление элемента в стек '%s' успешно\n", name)

	case "SPOP":
		if len(args) != 2 {
			fmt.Println("Ошибка: неверное количество аргументов для SPOP")
			return
		}
		stack, exists := stacks[name]
		if !exists {
			fmt.Printf("Ошибка: стек '%s' не существует\n", name)
			return
		}
		if stack.head == nil {
			fmt.Println("Ошибка: стек пуст")
			return
		}
		value := stack.head.value
		pop(stack)
		fmt.Printf("Удаление элемента из стека '%s' успешно. Удаленный элемент: %s\n", name, value)
	}
}

// Остальные функции processQueueCommand, processForwardListCommand, processDoubleListCommand, printHelp, main остаются без изменений...
